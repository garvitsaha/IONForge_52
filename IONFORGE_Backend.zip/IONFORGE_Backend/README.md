# IONFORGE Backend

Backend for the IONFORGE Fall Detection & Monitoring dashboard.

## 1. Requirements

Install Node.js 18+.

## 2. Install

Open a terminal in this folder:

```bash
npm install
```

For development:

```bash
npm install
npm run dev
```

For normal execution:

```bash
npm start
```

The API runs at:

http://localhost:5000

Health check:

http://localhost:5000/api/health

## 3. Frontend connection

The IONFORGE frontend should use:

```javascript
const API = "http://localhost:5000/api";
```

REST example:

```javascript
const response = await fetch(`${API}/dashboard`);
const data = await response.json();
console.log(data);
```

Socket.IO example:

```javascript
const socket = io("http://localhost:5000");

socket.on("fall:detected", payload => {
    console.log("Fall detected:", payload);
});
```

The current frontend supplied with the project contains simulation functions.
Those functions need to be replaced with fetch()/Socket.IO calls to make the
browser receive live backend data.

## 4. ESP32 fall request

When the armband detects a fall while Wi-Fi is available:

POST

`http://localhost:5000/api/esp32/fall`

JSON:

```json
{
  "deviceId": "IF-ARM-001",
  "personId": "RD001",
  "latitude": 22.9876,
  "longitude": 88.4352,
  "gpsAccuracy": 5
}
```

The backend:

1. creates the fall event;
2. updates the device GPS position;
3. records the event;
4. creates a notification;
5. sends/simulates SMS;
6. sends/simulates WhatsApp;
7. broadcasts the event to the dashboard over Socket.IO.

## 5. Offline event synchronization

If Wi-Fi is unavailable, the ESP32 should store the event locally.

After Wi-Fi reconnects:

POST

`http://localhost:5000/api/offline/sync`

Example:

```json
{
  "deviceId": "IF-ARM-001",
  "events": [
    {
      "id": "ESP32-OFFLINE-001",
      "personId": "RD001",
      "detectedAt": "2026-09-28T15:17:00+05:30",
      "latitude": 22.9876,
      "longitude": 88.4352,
      "gpsAccuracy": 8
    }
  ]
}
```

The backend processes each event and removes successfully synchronized
events from the server-side offline queue.

## 6. Acknowledgement

POST:

`/api/falls/:eventId/acknowledge`

Example:

```json
{
  "userName": "Sushmita Das"
}
```

## 7. Caregiver reminder

POST:

`/api/falls/:eventId/reminder`

## 8. Important prototype note

By default SMS and WhatsApp are simulated. No real message is sent unless
Twilio credentials are configured.

For production, use:

- proper user authentication;
- hashed passwords;
- JWT or secure session cookies;
- HTTPS;
- MongoDB/PostgreSQL;
- device authentication/API keys;
- rate limiting;
- validation;
- encrypted secrets;
- real SMS/WhatsApp provider;
- proper ESP32 TLS certificate validation.

## 9. Main API groups

GET  /api/health
POST /api/auth/login
POST /api/auth/logout

GET  /api/dashboard

GET   /api/devices
GET   /api/devices/:deviceId
PATCH /api/devices/:deviceId/status

POST /api/devices/:deviceId/location

GET  /api/falls
GET  /api/falls/:eventId
POST /api/falls
POST /api/esp32/fall

POST /api/falls/:eventId/acknowledge
POST /api/falls/:eventId/reminder

GET  /api/offline
POST /api/offline/queue
POST /api/offline/sync

GET   /api/caregivers
POST  /api/caregivers
PATCH /api/caregivers/:caregiverId

GET   /api/notifications
PATCH /api/notifications/read-all
PATCH /api/notifications/:notificationId/read

GET /api/logs

GET   /api/settings
PATCH /api/settings

POST /api/esp32/heartbeat
POST /api/esp32/fall
