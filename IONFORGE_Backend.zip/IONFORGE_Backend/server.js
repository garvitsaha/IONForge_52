/*
=========================================================
 IONFORGE BACKEND
 Fall Detection & Caregiver Monitoring API
=========================================================

Architecture:
ESP32 Armband
      ↓ Wi-Fi
IONFORGE Backend (Node.js + Express + Socket.IO)
      ↓
JSON persistence + notification services
      ↓
IONFORGE Dashboard

This backend is intentionally easy to run for a college/hackathon
prototype. It uses a local JSON file instead of requiring MongoDB.

Optional production integrations:
- Twilio SMS
- Twilio WhatsApp
- MongoDB
- HTTPS
- Real authentication/JWT
=========================================================
*/

require("dotenv").config();

const express = require("express");
const cors = require("cors");
const http = require("http");
const { Server } = require("socket.io");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const app = express();
const server = http.createServer(app);

const PORT = Number(process.env.PORT || 5000);
const CLIENT_ORIGIN = process.env.CLIENT_ORIGIN || "*";

const io = new Server(server, {
  cors: {
    origin: CLIENT_ORIGIN === "*" ? true : CLIENT_ORIGIN,
    methods: ["GET", "POST", "PATCH", "DELETE"]
  }
});

app.use(cors({
  origin: CLIENT_ORIGIN === "*" ? true : CLIENT_ORIGIN,
  credentials: true
}));

app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: true }));

const DATA_DIR = path.join(__dirname, "data");
const DATA_FILE = path.join(DATA_DIR, "ionforge-data.json");

function nowISO() {
  return new Date().toISOString();
}

function prettyDate(iso) {
  return new Date(iso).toLocaleString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    hour12: true
  });
}

function id(prefix) {
  return `${prefix}-${Date.now()}-${crypto.randomBytes(3).toString("hex")}`;
}

function ensureDataFile() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

  if (!fs.existsSync(DATA_FILE)) {
    const initial = {
      users: [],
      devices: [
        {
          id: "IF-ARM-001",
          personName: "Rohan Das",
          personId: "RD001",
          age: 68,
          online: true,
          gpsActive: true,
          latitude: 22.9876,
          longitude: 88.4352,
          gpsAccuracy: 5,
          battery: 87,
          firmware: "v1.4.2",
          simInstalled: false,
          fallSensor: "Operational",
          lastSeen: nowISO()
        }
      ],
      caregivers: [
        {
          id: "CG-001",
          name: "Sushmita Das",
          relationship: "Family / Primary Caregiver",
          phone: "+91 98765 43210",
          email: "sushmita@ionforge.com",
          smsEnabled: true,
          whatsappEnabled: true,
          offlineSyncEnabled: true,
          active: true
        }
      ],
      events: [
        {
          id: "ION-FALL-20260928-001",
          deviceId: "IF-ARM-001",
          personId: "RD001",
          detectedAt: "2026-09-28T09:47:00.000Z",
          latitude: 22.9876,
          longitude: 88.4352,
          gpsAccuracy: 5,
          smsStatus: "Sent",
          whatsappStatus: "Sent",
          acknowledgement: "No",
          source: "online"
        },
        {
          id: "ION-FALL-20260926-002",
          deviceId: "IF-ARM-001",
          personId: "RD001",
          detectedAt: "2026-09-26T02:45:00.000Z",
          latitude: 22.9781,
          longitude: 88.4210,
          gpsAccuracy: 5,
          smsStatus: "Sent",
          whatsappStatus: "Sent",
          acknowledgement: "Yes",
          source: "online"
        },
        {
          id: "ION-FALL-20260924-003",
          deviceId: "IF-ARM-001",
          personId: "RD001",
          detectedAt: "2026-09-24T13:02:00.000Z",
          latitude: 22.9654,
          longitude: 88.4167,
          gpsAccuracy: 5,
          smsStatus: "Sent",
          whatsappStatus: "Sent",
          acknowledgement: "Yes",
          source: "online"
        }
      ],
      offlineQueue: [
        {
          id: "OFFLINE-001",
          deviceId: "IF-ARM-001",
          detectedAt: "2026-09-28T07:35:00.000Z",
          latitude: 22.9876,
          longitude: 88.4352,
          gpsAccuracy: 7,
          status: "Waiting for sync"
        },
        {
          id: "OFFLINE-002",
          deviceId: "IF-ARM-001",
          detectedAt: "2026-09-27T14:45:00.000Z",
          latitude: 22.9781,
          longitude: 88.4210,
          gpsAccuracy: 8,
          status: "Waiting for sync"
        }
      ],
      notifications: [],
      logs: [
        {
          type: "green",
          message: "Armband connected to Wi-Fi",
          createdAt: "2026-09-28T09:46:00.000Z"
        }
      ]
    };

    fs.writeFileSync(DATA_FILE, JSON.stringify(initial, null, 2));
  }
}

function readDB() {
  ensureDataFile();
  return JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
}

function writeDB(db) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(db, null, 2));
}

function addLog(db, type, message) {
  db.logs.unshift({
    type,
    message,
    createdAt: nowISO()
  });

  db.logs = db.logs.slice(0, 100);
}

function addNotification(db, title, message, type = "alert") {
  const notification = {
    id: id("NOTIF"),
    title,
    message,
    type,
    read: false,
    createdAt: nowISO()
  };

  db.notifications.unshift(notification);
  db.notifications = db.notifications.slice(0, 100);

  return notification;
}

function emitDashboardUpdate(event, payload = {}) {
  io.emit(event, {
    ...payload,
    emittedAt: nowISO()
  });
}

async function sendSMS(caregiver, event) {
  /*
    Real Twilio implementation can be enabled with:
      TWILIO_ACCOUNT_SID
      TWILIO_AUTH_TOKEN
      TWILIO_PHONE_NUMBER

    For now this function returns a simulated result so the
    backend works without paid external services.
  */

  if (
    process.env.TWILIO_ACCOUNT_SID &&
    process.env.TWILIO_AUTH_TOKEN &&
    process.env.TWILIO_PHONE_NUMBER
  ) {
    try {
      const twilio = require("twilio");
      const client = twilio(
        process.env.TWILIO_ACCOUNT_SID,
        process.env.TWILIO_AUTH_TOKEN
      );

      const message = await client.messages.create({
        body:
          `IONFORGE FALL ALERT\n` +
          `Fall detected for ${event.personId}.\n` +
          `Location: ${event.latitude}, ${event.longitude}\n` +
          `Google Maps: https://www.google.com/maps?q=${event.latitude},${event.longitude}`,
        from: process.env.TWILIO_PHONE_NUMBER,
        to: caregiver.phone
      });

      return {
        status: "Sent",
        provider: "Twilio",
        messageId: message.sid
      };
    } catch (error) {
      console.error("Twilio SMS error:", error.message);
      return {
        status: "Failed",
        provider: "Twilio",
        error: error.message
      };
    }
  }

  return {
    status: "Sent",
    provider: "Simulation"
  };
}

async function sendWhatsApp(caregiver, event) {
  /*
    If Twilio credentials and a WhatsApp-enabled sender are
    configured, this can be changed to:
      from: "whatsapp:+YOUR_TWILIO_WHATSAPP_NUMBER"
      to: "whatsapp:+CAREGIVER_NUMBER"

    The simulation is enabled by default.
  */

  if (
    process.env.TWILIO_ACCOUNT_SID &&
    process.env.TWILIO_AUTH_TOKEN &&
    process.env.TWILIO_WHATSAPP_FROM
  ) {
    try {
      const twilio = require("twilio");
      const client = twilio(
        process.env.TWILIO_ACCOUNT_SID,
        process.env.TWILIO_AUTH_TOKEN
      );

      const message = await client.messages.create({
        body:
          `🚨 IONFORGE FALL ALERT\n` +
          `Fall detected for ${event.personId}.\n` +
          `Coordinates: ${event.latitude}, ${event.longitude}\n` +
          `Location: https://www.google.com/maps?q=${event.latitude},${event.longitude}`,
        from: `whatsapp:${process.env.TWILIO_WHATSAPP_FROM}`,
        to: `whatsapp:${caregiver.phone}`
      });

      return {
        status: "Sent",
        provider: "Twilio WhatsApp",
        messageId: message.sid
      };
    } catch (error) {
      console.error("Twilio WhatsApp error:", error.message);
      return {
        status: "Failed",
        provider: "Twilio WhatsApp",
        error: error.message
      };
    }
  }

  return {
    status: "Sent",
    provider: "Simulation"
  };
}

async function notifyCaregiver(db, event) {
  const caregiver = db.caregivers.find(c => c.active);

  if (!caregiver) {
    return {
      sms: { status: "No caregiver" },
      whatsapp: { status: "No caregiver" }
    };
  }

  const results = {
    sms: { status: "Disabled" },
    whatsapp: { status: "Disabled" }
  };

  if (caregiver.smsEnabled) {
    results.sms = await sendSMS(caregiver, event);
  }

  if (caregiver.whatsappEnabled) {
    results.whatsapp = await sendWhatsApp(caregiver, event);
  }

  return results;
}

/* =========================================================
   HEALTH / SYSTEM
========================================================= */

app.get("/", (req, res) => {
  res.json({
    service: "IONFORGE Backend",
    status: "online",
    version: "1.0.0",
    timestamp: nowISO()
  });
});

app.get("/api/health", (req, res) => {
  const db = readDB();

  res.json({
    status: "ok",
    backend: "connected",
    deviceOnline: db.devices.some(d => d.online),
    database: "local-json",
    timestamp: nowISO()
  });
});

/* =========================================================
   AUTHENTICATION
========================================================= */

app.post("/api/auth/login", (req, res) => {
  const { name, email, role } = req.body;

  if (!name || !email || !role) {
    return res.status(400).json({
      success: false,
      message: "Name, email and role are required."
    });
  }

  /*
    This prototype intentionally does not store passwords.
    For production, replace this with hashed passwords + JWT.
  */

  const user = {
    id: id("USER"),
    name: String(name).trim(),
    email: String(email).trim().toLowerCase(),
    role: String(role).trim()
  };

  const db = readDB();

  const existingIndex = db.users.findIndex(
    u => u.email === user.email
  );

  if (existingIndex >= 0) {
    db.users[existingIndex] = {
      ...db.users[existingIndex],
      ...user
    };
  } else {
    db.users.push(user);
  }

  writeDB(db);

  res.json({
    success: true,
    user
  });
});

app.post("/api/auth/logout", (req, res) => {
  res.json({
    success: true,
    message: "Signed out"
  });
});

/* =========================================================
   DASHBOARD
========================================================= */

app.get("/api/dashboard", (req, res) => {
  const db = readDB();

  const device = db.devices[0];
  const caregiver = db.caregivers.find(c => c.active) || null;
  const latestEvent = db.events[0] || null;

  res.json({
    success: true,
    system: {
      online: true,
      backendConnected: true,
      timestamp: nowISO()
    },
    device,
    caregiver,
    latestEvent,
    offlineQueue: db.offlineQueue,
    notifications: db.notifications.slice(0, 10),
    logs: db.logs.slice(0, 10)
  });
});

/* =========================================================
   DEVICES
========================================================= */

app.get("/api/devices", (req, res) => {
  const db = readDB();
  res.json({
    success: true,
    devices: db.devices
  });
});

app.get("/api/devices/:deviceId", (req, res) => {
  const db = readDB();
  const device = db.devices.find(d => d.id === req.params.deviceId);

  if (!device) {
    return res.status(404).json({
      success: false,
      message: "Device not found"
    });
  }

  res.json({
    success: true,
    device
  });
});

app.patch("/api/devices/:deviceId/status", (req, res) => {
  const db = readDB();
  const device = db.devices.find(d => d.id === req.params.deviceId);

  if (!device) {
    return res.status(404).json({
      success: false,
      message: "Device not found"
    });
  }

  const { online, latitude, longitude, gpsActive, battery } = req.body;

  if (typeof online === "boolean") device.online = online;
  if (typeof gpsActive === "boolean") device.gpsActive = gpsActive;
  if (latitude !== undefined) device.latitude = Number(latitude);
  if (longitude !== undefined) device.longitude = Number(longitude);
  if (battery !== undefined) device.battery = Number(battery);

  device.lastSeen = nowISO();

  addLog(
    db,
    device.online ? "green" : "amber",
    device.online
      ? `Armband ${device.id} connected to Wi-Fi`
      : `Armband ${device.id} disconnected from Wi-Fi`
  );

  writeDB(db);

  emitDashboardUpdate("device:status", { device });

  res.json({
    success: true,
    device
  });
});

/* =========================================================
   GPS
========================================================= */

app.post("/api/devices/:deviceId/location", (req, res) => {
  const db = readDB();
  const device = db.devices.find(d => d.id === req.params.deviceId);

  if (!device) {
    return res.status(404).json({
      success: false,
      message: "Device not found"
    });
  }

  const { latitude, longitude, accuracy } = req.body;

  if (
    typeof latitude !== "number" ||
    typeof longitude !== "number"
  ) {
    return res.status(400).json({
      success: false,
      message: "latitude and longitude must be numbers"
    });
  }

  device.latitude = latitude;
  device.longitude = longitude;

  if (accuracy !== undefined) {
    device.gpsAccuracy = Number(accuracy);
  }

  device.gpsActive = true;
  device.lastSeen = nowISO();

  writeDB(db);

  emitDashboardUpdate("gps:update", { device });

  res.json({
    success: true,
    location: {
      latitude: device.latitude,
      longitude: device.longitude,
      accuracy: device.gpsAccuracy
    }
  });
});

/* =========================================================
   FALL EVENTS
========================================================= */

app.get("/api/falls", (req, res) => {
  const db = readDB();

  let events = [...db.events];

  if (req.query.ack === "yes") {
    events = events.filter(e => e.acknowledgement === "Yes");
  }

  if (req.query.ack === "no") {
    events = events.filter(e => e.acknowledgement !== "Yes");
  }

  if (req.query.search) {
    const search = String(req.query.search).toLowerCase();

    events = events.filter(e =>
      `${e.id} ${e.detectedAt} ${e.latitude} ${e.longitude}`
        .toLowerCase()
        .includes(search)
    );
  }

  res.json({
    success: true,
    count: events.length,
    events
  });
});

app.get("/api/falls/:eventId", (req, res) => {
  const db = readDB();

  const event = db.events.find(
    e => e.id === req.params.eventId
  );

  if (!event) {
    return res.status(404).json({
      success: false,
      message: "Fall event not found"
    });
  }

  res.json({
    success: true,
    event
  });
});

/*
  ESP32 should call this endpoint when a fall is detected
  and Wi-Fi is available.

  Example:
  POST /api/falls
  {
    "deviceId": "IF-ARM-001",
    "personId": "RD001",
    "latitude": 22.9876,
    "longitude": 88.4352,
    "gpsAccuracy": 5
  }
*/

app.post("/api/falls", async (req, res) => {
  const db = readDB();

  const {
    deviceId = "IF-ARM-001",
    personId = "RD001",
    latitude,
    longitude,
    gpsAccuracy = 5,
    source = "online"
  } = req.body;

  const device = db.devices.find(d => d.id === deviceId);

  if (!device) {
    return res.status(404).json({
      success: false,
      message: "Device not registered"
    });
  }

  if (
    typeof latitude !== "number" ||
    typeof longitude !== "number"
  ) {
    return res.status(400).json({
      success: false,
      message: "Valid latitude and longitude are required"
    });
  }

  const event = {
    id: id("ION-FALL"),
    deviceId,
    personId,
    detectedAt: nowISO(),
    latitude,
    longitude,
    gpsAccuracy,
    smsStatus: "Processing",
    whatsappStatus: "Processing",
    acknowledgement: "No",
    source
  };

  db.events.unshift(event);

  device.latitude = latitude;
  device.longitude = longitude;
  device.gpsAccuracy = gpsAccuracy;
  device.online = true;
  device.lastSeen = nowISO();

  addLog(
    db,
    "red",
    `Fall event ${event.id} detected by ${deviceId}`
  );

  addNotification(
    db,
    "Fall event detected",
    `Fall detected for ${personId} at ${latitude}, ${longitude}`,
    "fall"
  );

  writeDB(db);

  emitDashboardUpdate("fall:detected", { event });

  const notificationResult = await notifyCaregiver(db, event);

  event.smsStatus = notificationResult.sms.status;
  event.whatsappStatus = notificationResult.whatsapp.status;

  if (event.smsStatus === "Sent") {
    addLog(db, "blue", "SMS sent to caregiver");
  }

  if (event.whatsappStatus === "Sent") {
    addLog(db, "green", "WhatsApp message sent to caregiver");
  }

  writeDB(db);

  emitDashboardUpdate("fall:notifications", {
    eventId: event.id,
    smsStatus: event.smsStatus,
    whatsappStatus: event.whatsappStatus
  });

  res.status(201).json({
    success: true,
    event,
    notifications: notificationResult
  });
});

/* =========================================================
   ACKNOWLEDGEMENT
========================================================= */

app.post("/api/falls/:eventId/acknowledge", (req, res) => {
  const db = readDB();

  const event = db.events.find(
    e => e.id === req.params.eventId
  );

  if (!event) {
    return res.status(404).json({
      success: false,
      message: "Fall event not found"
    });
  }

  event.acknowledgement = "Yes";
  event.acknowledgedAt = nowISO();
  event.acknowledgedBy = req.body?.userName || "Caregiver";

  addLog(
    db,
    "green",
    `Caregiver acknowledged fall event ${event.id}`
  );

  addNotification(
    db,
    "Fall acknowledged",
    `${event.acknowledgedBy} acknowledged ${event.id}`,
    "acknowledgement"
  );

  writeDB(db);

  emitDashboardUpdate("fall:acknowledged", { event });

  res.json({
    success: true,
    event
  });
});

/* =========================================================
   CAREGIVER REMINDER
========================================================= */

app.post("/api/falls/:eventId/reminder", async (req, res) => {
  const db = readDB();

  const event = db.events.find(
    e => e.id === req.params.eventId
  );

  if (!event) {
    return res.status(404).json({
      success: false,
      message: "Fall event not found"
    });
  }

  const caregiver = db.caregivers.find(c => c.active);

  if (!caregiver) {
    return res.status(404).json({
      success: false,
      message: "No active caregiver"
    });
  }

  addLog(
    db,
    "blue",
    `Caregiver reminder sent for ${event.id}`
  );

  addNotification(
    db,
    "Caregiver reminder sent",
    `Reminder sent regarding ${event.id}`,
    "reminder"
  );

  writeDB(db);

  emitDashboardUpdate("caregiver:reminder", {
    eventId: event.id
  });

  res.json({
    success: true,
    message: "Reminder sent",
    channels: {
      sms: caregiver.smsEnabled,
      whatsapp: caregiver.whatsappEnabled
    }
  });
});

/* =========================================================
   OFFLINE-FIRST QUEUE
========================================================= */

app.get("/api/offline", (req, res) => {
  const db = readDB();

  res.json({
    success: true,
    count: db.offlineQueue.length,
    queue: db.offlineQueue
  });
});

/*
  ESP32 can call this endpoint after Wi-Fi reconnects to
  upload one or more events captured while offline.
*/

app.post("/api/offline/sync", async (req, res) => {
  const db = readDB();

  const deviceId = req.body.deviceId || "IF-ARM-001";
  const events = Array.isArray(req.body.events)
    ? req.body.events
    : [];

  if (!events.length) {
    return res.status(400).json({
      success: false,
      message: "No offline events supplied"
    });
  }

  const synced = [];

  for (const offlineEvent of events) {
    if (
      typeof offlineEvent.latitude !== "number" ||
      typeof offlineEvent.longitude !== "number"
    ) {
      continue;
    }

    const event = {
      id: offlineEvent.id || id("ION-FALL"),
      deviceId,
      personId: offlineEvent.personId || "RD001",
      detectedAt: offlineEvent.detectedAt || nowISO(),
      latitude: offlineEvent.latitude,
      longitude: offlineEvent.longitude,
      gpsAccuracy: offlineEvent.gpsAccuracy || 10,
      smsStatus: "Processing",
      whatsappStatus: "Processing",
      acknowledgement: "No",
      source: "offline-sync"
    };

    db.events.unshift(event);

    const notificationResult = await notifyCaregiver(db, event);

    event.smsStatus = notificationResult.sms.status;
    event.whatsappStatus = notificationResult.whatsapp.status;

    addLog(
      db,
      "green",
      `Offline event ${event.id} synchronized to backend`
    );

    addNotification(
      db,
      "Offline event synchronized",
      `${event.id} has been uploaded and processed`,
      "sync"
    );

    synced.push(event);
  }

  db.offlineQueue = db.offlineQueue.filter(
    queued =>
      !synced.some(
        event =>
          event.id === queued.id ||
          (
            event.latitude === queued.latitude &&
            event.longitude === queued.longitude &&
            event.detectedAt === queued.detectedAt
          )
      )
  );

  writeDB(db);

  emitDashboardUpdate("offline:synced", {
    synced,
    remaining: db.offlineQueue.length
  });

  res.json({
    success: true,
    syncedCount: synced.length,
    synced,
    remaining: db.offlineQueue.length
  });
});

/*
  Optional endpoint for testing offline storage from the
  dashboard/backend without an ESP32.
*/

app.post("/api/offline/queue", (req, res) => {
  const db = readDB();

  const item = {
    id: req.body.id || id("OFFLINE"),
    deviceId: req.body.deviceId || "IF-ARM-001",
    personId: req.body.personId || "RD001",
    detectedAt: req.body.detectedAt || nowISO(),
    latitude: Number(req.body.latitude),
    longitude: Number(req.body.longitude),
    gpsAccuracy: Number(req.body.gpsAccuracy || 10),
    status: "Waiting for sync"
  };

  if (
    !Number.isFinite(item.latitude) ||
    !Number.isFinite(item.longitude)
  ) {
    return res.status(400).json({
      success: false,
      message: "Valid coordinates are required"
    });
  }

  db.offlineQueue.unshift(item);

  addLog(
    db,
    "amber",
    `Offline event ${item.id} queued locally`
  );

  writeDB(db);

  emitDashboardUpdate("offline:queued", { item });

  res.status(201).json({
    success: true,
    item
  });
});

/* =========================================================
   CAREGIVERS
========================================================= */

app.get("/api/caregivers", (req, res) => {
  const db = readDB();

  res.json({
    success: true,
    caregivers: db.caregivers
  });
});

app.post("/api/caregivers", (req, res) => {
  const db = readDB();

  const {
    name,
    relationship,
    phone,
    email,
    smsEnabled = true,
    whatsappEnabled = true,
    offlineSyncEnabled = true
  } = req.body;

  if (!name || !phone) {
    return res.status(400).json({
      success: false,
      message: "Name and phone are required"
    });
  }

  const caregiver = {
    id: id("CG"),
    name,
    relationship: relationship || "Caregiver",
    phone,
    email: email || "",
    smsEnabled,
    whatsappEnabled,
    offlineSyncEnabled,
    active: true
  };

  db.caregivers.push(caregiver);
  writeDB(db);

  emitDashboardUpdate("caregiver:added", { caregiver });

  res.status(201).json({
    success: true,
    caregiver
  });
});

app.patch("/api/caregivers/:caregiverId", (req, res) => {
  const db = readDB();

  const caregiver = db.caregivers.find(
    c => c.id === req.params.caregiverId
  );

  if (!caregiver) {
    return res.status(404).json({
      success: false,
      message: "Caregiver not found"
    });
  }

  Object.assign(caregiver, {
    name: req.body.name ?? caregiver.name,
    relationship: req.body.relationship ?? caregiver.relationship,
    phone: req.body.phone ?? caregiver.phone,
    email: req.body.email ?? caregiver.email,
    smsEnabled: req.body.smsEnabled ?? caregiver.smsEnabled,
    whatsappEnabled:
      req.body.whatsappEnabled ?? caregiver.whatsappEnabled,
    offlineSyncEnabled:
      req.body.offlineSyncEnabled ?? caregiver.offlineSyncEnabled,
    active: req.body.active ?? caregiver.active
  });

  writeDB(db);

  emitDashboardUpdate("caregiver:updated", { caregiver });

  res.json({
    success: true,
    caregiver
  });
});

/* =========================================================
   NOTIFICATIONS
========================================================= */

app.get("/api/notifications", (req, res) => {
  const db = readDB();

  res.json({
    success: true,
    unread: db.notifications.filter(n => !n.read).length,
    notifications: db.notifications
  });
});

app.patch("/api/notifications/read-all", (req, res) => {
  const db = readDB();

  db.notifications.forEach(n => {
    n.read = true;
  });

  writeDB(db);

  emitDashboardUpdate("notifications:read-all");

  res.json({
    success: true
  });
});

app.patch("/api/notifications/:notificationId/read", (req, res) => {
  const db = readDB();

  const notification = db.notifications.find(
    n => n.id === req.params.notificationId
  );

  if (!notification) {
    return res.status(404).json({
      success: false,
      message: "Notification not found"
    });
  }

  notification.read = true;

  writeDB(db);

  res.json({
    success: true,
    notification
  });
});

/* =========================================================
   LOGS
========================================================= */

app.get("/api/logs", (req, res) => {
  const db = readDB();

  res.json({
    success: true,
    logs: db.logs.slice(0, Number(req.query.limit || 50))
  });
});

/* =========================================================
   SETTINGS
========================================================= */

let settings = {
  fallSensitivity: "High",
  notificationRetryInterval: "30 seconds",
  gpsAccuracyThreshold: "5 meters",
  storeEventsLocally: true,
  autoSyncOnReconnect: true,
  notifyOnDelayedSync: true
};

app.get("/api/settings", (req, res) => {
  res.json({
    success: true,
    settings
  });
});

app.patch("/api/settings", (req, res) => {
  settings = {
    ...settings,
    ...req.body
  };

  res.json({
    success: true,
    settings
  });
});

/* =========================================================
   ESP32 DEVICE API
========================================================= */

/*
  Health/status endpoint intended for the ESP32.
*/

app.post("/api/esp32/heartbeat", (req, res) => {
  const db = readDB();

  const {
    deviceId = "IF-ARM-001",
    battery,
    latitude,
    longitude,
    gpsAccuracy
  } = req.body;

  const device = db.devices.find(d => d.id === deviceId);

  if (!device) {
    return res.status(404).json({
      success: false,
      message: "Unknown ESP32 device"
    });
  }

  device.online = true;
  device.lastSeen = nowISO();

  if (battery !== undefined) device.battery = Number(battery);
  if (latitude !== undefined) device.latitude = Number(latitude);
  if (longitude !== undefined) device.longitude = Number(longitude);
  if (gpsAccuracy !== undefined) device.gpsAccuracy = Number(gpsAccuracy);

  device.gpsActive =
    typeof latitude === "number" &&
    typeof longitude === "number";

  writeDB(db);

  emitDashboardUpdate("esp32:heartbeat", { device });

  res.json({
    success: true,
    serverTime: nowISO(),
    device
  });
});

/*
  ESP32 sends a fall here.
  This is a convenience alias around /api/falls.
*/

app.post("/api/esp32/fall", async (req, res) => {
  req.body.source = "esp32";

  const db = readDB();

  const {
    deviceId = "IF-ARM-001",
    personId = "RD001",
    latitude,
    longitude,
    gpsAccuracy = 5
  } = req.body;

  if (
    typeof latitude !== "number" ||
    typeof longitude !== "number"
  ) {
    return res.status(400).json({
      success: false,
      message: "ESP32 must provide numeric latitude and longitude"
    });
  }

  const device = db.devices.find(d => d.id === deviceId);

  if (!device) {
    return res.status(404).json({
      success: false,
      message: "Device not registered"
    });
  }

  const event = {
    id: id("ION-FALL"),
    deviceId,
    personId,
    detectedAt: nowISO(),
    latitude,
    longitude,
    gpsAccuracy,
    smsStatus: "Processing",
    whatsappStatus: "Processing",
    acknowledgement: "No",
    source: "esp32"
  };

  db.events.unshift(event);

  device.online = true;
  device.lastSeen = nowISO();
  device.latitude = latitude;
  device.longitude = longitude;
  device.gpsAccuracy = gpsAccuracy;

  addLog(
    db,
    "red",
    `ESP32 reported fall event ${event.id}`
  );

  addNotification(
    db,
    "🚨 Fall Detected",
    `ESP32 ${deviceId} detected a fall at ${latitude}, ${longitude}`,
    "fall"
  );

  writeDB(db);

  emitDashboardUpdate("fall:detected", { event });

  const notificationResult = await notifyCaregiver(db, event);

  event.smsStatus = notificationResult.sms.status;
  event.whatsappStatus = notificationResult.whatsapp.status;

  writeDB(db);

  emitDashboardUpdate("fall:notifications", {
    eventId: event.id,
    smsStatus: event.smsStatus,
    whatsappStatus: event.whatsappStatus
  });

  res.status(201).json({
    success: true,
    event,
    notifications: notificationResult
  });
});

/* =========================================================
   404 + ERROR HANDLING
========================================================= */

app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: "IONFORGE API endpoint not found",
    path: req.originalUrl
  });
});

app.use((err, req, res, next) => {
  console.error("IONFORGE server error:", err);

  res.status(500).json({
    success: false,
    message: "Internal server error",
    error:
      process.env.NODE_ENV === "development"
        ? err.message
        : undefined
  });
});

/* =========================================================
   SOCKET.IO
========================================================= */

io.on("connection", socket => {
  console.log(`Dashboard connected: ${socket.id}`);

  socket.emit("connection:ready", {
    socketId: socket.id,
    serverTime: nowISO(),
    message: "IONFORGE real-time channel connected"
  });

  socket.on("device:subscribe", deviceId => {
    if (deviceId) {
      socket.join(`device:${deviceId}`);
      socket.emit("device:subscribed", { deviceId });
    }
  });

  socket.on("disconnect", reason => {
    console.log(`Dashboard disconnected: ${socket.id} (${reason})`);
  });
});

/* =========================================================
   START SERVER
========================================================= */

ensureDataFile();

server.listen(PORT, () => {
  console.log("");
  console.log("==============================================");
  console.log("        IONFORGE BACKEND ONLINE");
  console.log("==============================================");
  console.log(`REST API:  http://localhost:${PORT}`);
  console.log(`Health:    http://localhost:${PORT}/api/health`);
  console.log(`Socket.IO: ws://localhost:${PORT}`);
  console.log(`Data:      ${DATA_FILE}`);
  console.log("==============================================");
  console.log("");
});
